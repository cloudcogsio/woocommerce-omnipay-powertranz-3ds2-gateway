<?php

namespace Cloudcogs\Woocommerce\Gateway\PowerTranz\Api\DirectResponse;

use Cloudcogs\Woocommerce\Gateway\PowerTranz\Api\DirectResponse;

class Transaction extends DirectResponse
{

}
